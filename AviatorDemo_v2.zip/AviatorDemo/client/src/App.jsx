import React, { useState, useEffect, useRef } from 'react';
import ReactDOM from 'react-dom/client';
import io from 'socket.io-client';
import axios from 'axios';

const API = process.env.REACT_APP_API_URL || 'http://localhost:3001';
const SOCKET_URL = process.env.REACT_APP_API_URL || 'http://localhost:3001';

import Admin from './Admin';

function App(){
  const [mobile, setMobile] = useState('');
  const [otp, setOtp] = useState('');
  const [token, setToken] = useState(localStorage.getItem('token')||'');
  const [user, setUser] = useState(null);
  const [wallet, setWallet] = useState(null);
  const [socket, setSocket] = useState(null);
  const [roundHash, setRoundHash] = useState('');
  const [multiplier, setMultiplier] = useState(1.0);
  const [messages, setMessages] = useState([]);
  const [betAmount, setBetAmount] = useState(10);
  const [betId, setBetId] = useState(null);

  useEffect(()=>{
    if(token){
      axios.get(API + '/api/wallet', { headers: { Authorization: 'Bearer ' + token } }).then(r=> setWallet(r.data.wallet)).catch(()=>{});
    }
  }, [token]);

  useEffect(()=>{
    const s = io(SOCKET_URL);
    setSocket(s);
    s.on('round:new', (r)=>{ setRoundHash(r.hash); push('Round started — hash: '+ r.hash.slice(0,12)+'...'); setMultiplier(1.0); setBetId(null); });
    s.on('round:tick', (t)=> setMultiplier(t.multiplier));
    s.on('round:crash', (c)=> push('Round crashed at '+c.multiplier+'x — secret: '+c.secret.slice(0,12)+'...'));
    s.on('bet:accepted', (d)=> { push('Bet accepted id:'+d.betId); setBetId(d.betId); });
    s.on('bet:rejected', (d)=> push('Bet rejected: '+JSON.stringify(d)));
    s.on('cashout:ok', (d)=> push('Cashed out: '+d.payout+' at '+d.multiplier+'x'));
    return ()=> s.disconnect();
  }, []);

  function push(t){ setMessages(m=>[t,...m].slice(0,12)); }

  async function requestOtp(){
    try{ await axios.post(API + '/api/auth/request-otp', { mobile }); push('OTP requested (check server logs in demo)'); }
    catch(e){ push('Error requesting OTP'); }
  }
  async function verifyOtp(){
    try{ const r = await axios.post(API + '/api/auth/verify-otp', { mobile, otp }); setToken(r.data.token); localStorage.setItem('token', r.data.token); setUser(r.data.user); push('Logged in'); }
    catch(e){ push('OTP verify failed'); }
  }

  async function deposit(){
    const amt = parseFloat(prompt('Deposit amount INR')); if(!amt) return;
    await axios.post(API + '/api/wallet/deposit', { amount: amt }, { headers: { Authorization: 'Bearer ' + token } });
    const r = await axios.get(API + '/api/wallet', { headers: { Authorization: 'Bearer ' + token } }); setWallet(r.data.wallet); push('Deposited '+amt);
  }

  function placeBet(){
    if(!socket || !token) return alert('Login first');
    socket.emit('place_bet', { token, roundId: Date.now(), amount: betAmount });
  }

  function cashout(){
    if(!socket || !token || !betId) return alert('No bet');
    socket.emit('cashout', { token, betId });
  }

  return (<div style={{fontFamily:'sans-serif', padding:16}}>
    <div style={{marginBottom:8}}><a href='#admin' onClick={(e)=>{e.preventDefault(); document.getElementById('admin-area').scrollIntoView();}}>Go to Admin</a></div>

    <h2>Aviator Demo (INR) - Offline/Online hybrid</h2>
    {!token ? (<div>
      <input placeholder='Mobile' value={mobile} onChange={e=>setMobile(e.target.value)}/>
      <button onClick={requestOtp}>Request OTP</button><br/>
      <input placeholder='OTP' value={otp} onChange={e=>setOtp(e.target.value)} />
      <button onClick={verifyOtp}>Verify OTP</button>
    </div>) : (<div>Logged in: {user && user.mobile} <button onClick={()=>{localStorage.removeItem('token'); setToken(''); setUser(null);}}>Logout</button></div>)}
    <div style={{marginTop:12}}>
      <strong>Wallet:</strong> {wallet ? `${wallet.balance} ${wallet.currency}` : '—'} <button onClick={deposit}>Deposit</button>
    </div>
    <div style={{marginTop:12, padding:12, border:'1px solid #ddd', borderRadius:8, width:360}}>
      <div>Round hash: <code style={{fontSize:12}}>{roundHash.slice(0,16)}...</code></div>
      <div style={{fontSize:28, fontWeight:700}}>{multiplier}x</div>
      <div style={{marginTop:8}}>
        <input type='number' value={betAmount} onChange={e=>setBetAmount(Number(e.target.value))}/> <button onClick={placeBet}>Place Bet</button> <button onClick={cashout}>Cash Out</button>
      </div>
      <div style={{marginTop:8}}><strong>Messages</strong><div style={{fontSize:12, marginTop:6}}>{messages.map((m,i)=>(<div key={i}>{m}</div>))}</div></div>
    </div>
  <div id='admin-area' style={{marginTop:24}}><Admin/></div></div>);
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App/>);